-- --------------------------------------------------------
-- Host:                         localhost
-- Server versie:                5.7.19-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Versie:              9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Databasestructuur van spacemmo wordt geschreven
CREATE DATABASE IF NOT EXISTS `spacemmo` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_general_ci */;
USE `spacemmo`;

-- Structuur van  tabel spacemmo.faction wordt geschreven
CREATE TABLE IF NOT EXISTS `faction` (
  `name` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.faction: ~3 rows (ongeveer)
/*!40000 ALTER TABLE `faction` DISABLE KEYS */;
INSERT INTO `faction` (`name`) VALUES
	('BOLT'),
	('H3-RB'),
	('TRRA');
/*!40000 ALTER TABLE `faction` ENABLE KEYS */;

-- Structuur van  tabel spacemmo.region wordt geschreven
CREATE TABLE IF NOT EXISTS `region` (
  `faction` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `x` int(11) NOT NULL DEFAULT '0',
  `y` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`x`,`y`),
  KEY `FK__faction` (`faction`),
  CONSTRAINT `FK__faction` FOREIGN KEY (`faction`) REFERENCES `faction` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.region: ~51 rows (ongeveer)
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` (`faction`, `x`, `y`) VALUES
	('BOLT', 0, 3),
	('BOLT', 0, 4),
	('BOLT', 0, 5),
	('BOLT', 1, 3),
	('BOLT', 1, 5),
	('BOLT', 1, 6),
	('BOLT', 2, 6),
	('H3-RB', 0, 0),
	('H3-RB', 0, 1),
	('H3-RB', 0, 2),
	('H3-RB', 1, 0),
	('H3-RB', 1, 2),
	('H3-RB', 2, 0),
	('H3-RB', 2, 1),
	('H3-RB', 2, 2),
	('H3-RB', 2, 3),
	('H3-RB', 2, 4),
	('H3-RB', 2, 5),
	('H3-RB', 3, 0),
	('H3-RB', 3, 1),
	('H3-RB', 3, 2),
	('H3-RB', 3, 4),
	('H3-RB', 3, 5),
	('H3-RB', 4, 4),
	('H3-RB', 4, 5),
	('H3-RB', 5, 3),
	('H3-RB', 12, 1),
	('H3-RB', 12, 2),
	('H3-RB', 13, 0),
	('H3-RB', 13, 1),
	('H3-RB', 13, 2),
	('H3-RB', 14, 2),
	('TRRA', 1, 1),
	('TRRA', 1, 4),
	('TRRA', 1, 15),
	('TRRA', 1, 17),
	('TRRA', 3, 3),
	('TRRA', 3, 6),
	('TRRA', 3, 8),
	('TRRA', 3, 10),
	('TRRA', 3, 12),
	('TRRA', 3, 14),
	('TRRA', 3, 16),
	('TRRA', 3, 18),
	('TRRA', 3, 19),
	('TRRA', 4, 3),
	('TRRA', 5, 13),
	('TRRA', 5, 15),
	('TRRA', 6, 5),
	('TRRA', 14, 1),
	('TRRA', 15, 2);
/*!40000 ALTER TABLE `region` ENABLE KEYS */;

-- Structuur van  tabel spacemmo.sessions wordt geschreven
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int(11) unsigned NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.sessions: ~51 rows (ongeveer)
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`session_id`, `expires`, `data`) VALUES
	('0JeHXgSoa_JQ0GmfR5qBlL7BsYWc3UAJ', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('16gXNtDLLCvAFILQgVJ_h5eZE8g47sIO', 1511954786, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('1Nkwvp_DSRteC6lmnfBs7KbrYovZ0-Xf', 1511889852, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('1x7FZuc7KCVvU4Uwx9kugOQDdilWyGE7', 1511954783, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('3wUhKOxYTGVmUzyRBEWnKeRo00CLyyaG', 1511954781, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('47meH2N7OrFl-nkpX3mY3VyNbkPFfAxJ', 1511825228, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('4Q8hh5JAoSH1uwLk1N-S6Pu7XBNTJbBP', 1512647148, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly3","faction":"H3-RB","money":250}}'),
	('4WVVfiJuNHe46ZMozXJqlfvWZWEhOWau', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('4xuZwpd1cTEIT9OiuIoPsWjhsyqukjnc', 1511882066, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly2","faction":"BOLT","money":0}}'),
	('7RXX3bXXjfbmL5aRbhGNbcBOCPRtct4E', 1511881951, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly2","faction":"BOLT","money":0}}'),
	('8O1QgBGqtOiekDY4M0FmgyS-_Lu5Ko2M', 1511918161, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('9K5qYdPzUGAKOFNeVlQW4IUVn2TfmPZu', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('DqGd4TtdkkJ4tWbU7-iUFNCGtuv94Uwr', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('DqNhHgWHWkXFZSLK9kcZEV7hd444Doao', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('FFAztBN7zKJvrWKICWxzTtgw0Ij1Bj5I', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('GoPEqUGDgBnC2Xsam4ZysXBA6AVPh-NT', 1511825217, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('Gw6vfjun066Fm7RqrzCUOn6uFMT4M61p', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('HFlWrhbdCMH9MTPBZ4N9_uEQqKtFIpep', 1511867890, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('Jxk6zXPQ2ahTt7h4TSRM3tXSTxWUcm58', 1512761143, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"trra","faction":"TRRA","money":250}}'),
	('L0_w2-yJtbikY6sAaapqcn7d7IBsiOdS', 1512648907, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"h3rb","faction":"H3-RB","money":250}}'),
	('L7xyyBuHAjKD_AQhi3v2Y1uX_BSvs1Dt', 1511867891, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('MFaykQFqdFGbQ_aEtUATFZwYpnA9o3iR', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('MtLBOZwnX7aAVDu2zyhSvGuuy9HoGysx', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('NAZ8e0demxECiPr-HDh35hU-nbv7FfJW', 1511825217, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('NwH7iAk1bLWkV97zuAxVN54hqlEhpKrI', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('OUlurQaMPTw-Ra1DhvbJmvCdw3oFtFtw', 1511954784, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('SiENNrll-3nuNgT-1E1RNmylTyxQMa6e', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('TCj_GiDrPuclGBBqAS_XSipVZHTVijzd', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('VDXALiqra2v6AN0f2_lsYHFpUSbtc_VM', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('VEPcosuz0_vQYLcZpuUyGhWcTuXql4aM', 1511954781, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('X3WDOjd9qdjE4mvMdDWietKwwmO3HRcP', 1512647733, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('_t9Z_5AMw-DDhnko8iK7o_RU1B7jDGd8', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('aDCSoCdF5n6bK1uhaJ0Pm7Pfkk1bFn0-', 1511950221, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('as4XZ58XMD8aU31BumAUFrmMuSFHp4Xk', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('b9OC2rAfw4YxPHgxYwZrK9QUgXWkVBD8', 1511867888, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('bATrL9U0teER4go-6fTDx1MnksV4t7dX', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('bxnuNnC4op-GbVLd0BvqGe88CtK_8ZkQ', 1511795847, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('d2AvXwu4yF5lv08Z_wy_NPiqbG97nT4L', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('e8Nt7VcdJvaGmpjyKwm8jx6TLm0nK1f4', 1511867889, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('eOL0p-u8Sh5dytO9VpKzyRD6Pdbo4jhs', 1512648873, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"h3rb","faction":"H3-RB","money":250}}'),
	('emj8nlfdqYA8jRojYXoz0ECrUTFzwxGo', 1512650176, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"h3rb","faction":"H3-RB","money":250}}'),
	('fi4cCum7VH_EZY_Jy6_kdwgvm6gawkj-', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('ganzoG7YpbWBTzq2NkZ101vJQ1GU_u2x', 1512761241, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"trra","faction":"TRRA","money":250}}'),
	('ircO_fcR9QizkRRBq6sts1TcLVNCNu6k', 1511954781, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('iu0e2Z6bBv1dBlD5e7vOt8SOb-HnFOR8', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('lry_QlRrla330xlrPqRTwQvitgevwj2k', 1512648124, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"h3rb","faction":"H3-RB","money":250}}'),
	('mPGUS3SrzJ2_tV8hR19Ezm9cLFvKDo2f', 1511802029, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly2","faction":"BOLT","money":0}}'),
	('scihTuHYo3aPKIDlCcpNH3h4WK-kHqYQ', 1511954785, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('vc9ci0bqckgUV1Elh8e1jTqbzEq30IQr', 1511954782, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('vxpCgLwUVXNCMnSsQpAHRYxE2j1ItnU1', 1511795702, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('yigepnLJq4XdrtQB1TCX_BTicruXAeE8', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;

-- Structuur van  tabel spacemmo.user wordt geschreven
CREATE TABLE IF NOT EXISTS `user` (
  `login` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `password` char(60) COLLATE latin1_general_ci NOT NULL,
  `faction` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `money` int(11) NOT NULL DEFAULT '250',
  PRIMARY KEY (`login`),
  KEY `FK_user_faction` (`faction`),
  CONSTRAINT `FK_user_faction` FOREIGN KEY (`faction`) REFERENCES `faction` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.user: ~3 rows (ongeveer)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`login`, `password`, `faction`, `money`) VALUES
	('bolt', '$2a$08$zWnlmCjD/m.nQZn6AFNTuOr35ELHWCH2vw86kIDEp32jxExvhbx7G', 'BOLT', 250),
	('h3rb', '$2a$08$PimQsQld68yJ0opQwr2A/.bThmUoLlrFk.OMW3FAZXXQYYCw/2N0G', 'H3-RB', 250),
	('trra', '$2a$08$51wZM270UjajH.QMVQGbGe/CFz4U6Tvci4lDKSudi4pTlDAhpvpha', 'TRRA', 250);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- Structuur van  view spacemmo.worldpercent wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `worldpercent` (
	`BOLT` DECIMAL(30,4) NULL,
	`TRRA` DECIMAL(30,4) NULL,
	`H3-RB` DECIMAL(30,4) NULL
) ENGINE=MyISAM;

-- Structuur van  view spacemmo.worldpercent wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `worldpercent`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `worldpercent` AS select ((sum((case when (`region`.`faction` = 'BOLT') then 1 else 0 end)) / 400) * 100) AS `BOLT`,((sum((case when (`region`.`faction` = 'TRRA') then 1 else 0 end)) / 400) * 100) AS `TRRA`,((sum((case when (`region`.`faction` = 'H3-RB') then 1 else 0 end)) / 400) * 100) AS `H3-RB` from `region`;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

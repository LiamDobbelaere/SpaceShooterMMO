-- --------------------------------------------------------
-- Host:                         localhost
-- Server versie:                5.7.19-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Versie:              9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Databasestructuur van spacemmo wordt geschreven
CREATE DATABASE IF NOT EXISTS `spacemmo` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_general_ci */;
USE `spacemmo`;

-- Structuur van  tabel spacemmo.faction wordt geschreven
CREATE TABLE IF NOT EXISTS `faction` (
  `name` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.faction: ~2 rows (ongeveer)
/*!40000 ALTER TABLE `faction` DISABLE KEYS */;
INSERT INTO `faction` (`name`) VALUES
	('BOLT'),
	('TRRA');
/*!40000 ALTER TABLE `faction` ENABLE KEYS */;

-- Structuur van  tabel spacemmo.region wordt geschreven
CREATE TABLE IF NOT EXISTS `region` (
  `faction` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `x` int(11) NOT NULL DEFAULT '0',
  `y` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`x`,`y`),
  KEY `FK__faction` (`faction`),
  CONSTRAINT `FK__faction` FOREIGN KEY (`faction`) REFERENCES `faction` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.region: ~379 rows (ongeveer)
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` (`faction`, `x`, `y`) VALUES
	('TRRA', 1, 4),
	('TRRA', 1, 15),
	('TRRA', 1, 17),
	('TRRA', 3, 4),
	('TRRA', 3, 6),
	('TRRA', 3, 8),
	('TRRA', 3, 10),
	('TRRA', 3, 12),
	('TRRA', 3, 14),
	('TRRA', 3, 16),
	('TRRA', 3, 18),
	('TRRA', 3, 19),
	('TRRA', 5, 13),
	('TRRA', 5, 15);
/*!40000 ALTER TABLE `region` ENABLE KEYS */;

-- Structuur van  tabel spacemmo.sessions wordt geschreven
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int(11) unsigned NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.sessions: ~26 rows (ongeveer)
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`session_id`, `expires`, `data`) VALUES
	('1Nkwvp_DSRteC6lmnfBs7KbrYovZ0-Xf', 1511889852, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('47meH2N7OrFl-nkpX3mY3VyNbkPFfAxJ', 1511825228, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('4WVVfiJuNHe46ZMozXJqlfvWZWEhOWau', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('4xuZwpd1cTEIT9OiuIoPsWjhsyqukjnc', 1511882066, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly2","faction":"BOLT","money":0}}'),
	('7RXX3bXXjfbmL5aRbhGNbcBOCPRtct4E', 1511881951, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly2","faction":"BOLT","money":0}}'),
	('8O1QgBGqtOiekDY4M0FmgyS-_Lu5Ko2M', 1511918161, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('9K5qYdPzUGAKOFNeVlQW4IUVn2TfmPZu', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('DqNhHgWHWkXFZSLK9kcZEV7hd444Doao', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('FFAztBN7zKJvrWKICWxzTtgw0Ij1Bj5I', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('GoPEqUGDgBnC2Xsam4ZysXBA6AVPh-NT', 1511825217, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('Gw6vfjun066Fm7RqrzCUOn6uFMT4M61p', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('HFlWrhbdCMH9MTPBZ4N9_uEQqKtFIpep', 1511867890, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('L7xyyBuHAjKD_AQhi3v2Y1uX_BSvs1Dt', 1511867891, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('MtLBOZwnX7aAVDu2zyhSvGuuy9HoGysx', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('NAZ8e0demxECiPr-HDh35hU-nbv7FfJW', 1511825217, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('NwH7iAk1bLWkV97zuAxVN54hqlEhpKrI', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('as4XZ58XMD8aU31BumAUFrmMuSFHp4Xk', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('b9OC2rAfw4YxPHgxYwZrK9QUgXWkVBD8', 1511867888, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('bATrL9U0teER4go-6fTDx1MnksV4t7dX', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('bxnuNnC4op-GbVLd0BvqGe88CtK_8ZkQ', 1511795847, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('d2AvXwu4yF5lv08Z_wy_NPiqbG97nT4L', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('e8Nt7VcdJvaGmpjyKwm8jx6TLm0nK1f4', 1511867889, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('fi4cCum7VH_EZY_Jy6_kdwgvm6gawkj-', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}'),
	('mPGUS3SrzJ2_tV8hR19Ezm9cLFvKDo2f', 1511802029, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly2","faction":"BOLT","money":0}}'),
	('vxpCgLwUVXNCMnSsQpAHRYxE2j1ItnU1', 1511795702, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"},"user":{"login":"digaly","faction":"TRRA","money":100}}'),
	('yigepnLJq4XdrtQB1TCX_BTicruXAeE8', 1511867887, '{"cookie":{"originalMaxAge":null,"expires":null,"httpOnly":true,"path":"/"}}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;

-- Structuur van  tabel spacemmo.user wordt geschreven
CREATE TABLE IF NOT EXISTS `user` (
  `login` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `password` char(60) COLLATE latin1_general_ci NOT NULL,
  `faction` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `money` int(11) NOT NULL,
  PRIMARY KEY (`login`),
  KEY `FK_user_faction` (`faction`),
  CONSTRAINT `FK_user_faction` FOREIGN KEY (`faction`) REFERENCES `faction` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumpen data van tabel spacemmo.user: ~2 rows (ongeveer)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`login`, `password`, `faction`, `money`) VALUES
	('digaly', '$2a$08$61S9L623bPkYuq9gWqBF5.ulkB1TYt3HB/rR7HNM6lJNdw0b9o0aG', 'TRRA', 100),
	('digaly2', '$2a$08$QkDTgD4W.J9YB9n2FKDE/ueEOXaM37JFR9GXTqYQkkNzWmAU5NWaS', 'BOLT', 0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- Structuur van  view spacemmo.worldpercent wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `worldpercent` (
	`BOLT` DECIMAL(30,4) NULL,
	`TRRA` DECIMAL(30,4) NULL
) ENGINE=MyISAM;

-- Structuur van  view spacemmo.worldpercent wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `worldpercent`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `worldpercent` AS select ((sum((case when (`region`.`faction` = 'BOLT') then 1 else 0 end)) / 400) * 100) AS `BOLT`,((sum((case when (`region`.`faction` = 'TRRA') then 1 else 0 end)) / 400) * 100) AS `TRRA` from `region`;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
